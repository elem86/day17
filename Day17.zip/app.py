import pandas as pd
import glob
import os


# Match all Excel files in the directory
excel_files = glob.glob("*.xlsx")


# Empty list to store DataFrames
all_data = []

# Loop through all Excel files
for file in excel_files:
    df = pd.read_excel(file)
    df["source_file"] = os.path.basename(file)  # Optional: track source
    all_data.append(df)

# Combine into one DataFrame
merged_df = pd.concat(all_data, ignore_index=True)


print(merged_df.head())
print(merged_df.shape)

merged_df.to_excel("merged_bank_data.xlsx", index=False)
